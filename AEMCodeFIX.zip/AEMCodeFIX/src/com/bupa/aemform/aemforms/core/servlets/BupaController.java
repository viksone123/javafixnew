package com.bupa.aemform.aemforms.core.servlets;

import com.adobe.aemfd.docmanager.Document;
import com.adobe.fd.output.api.AcrobatVersion;
import com.adobe.fd.output.api.OutputService;
import com.adobe.fd.output.api.OutputServiceException;
import com.adobe.fd.output.api.PDFOutputOptions;
import com.bupa.aemform.aemforms.business.OutputServiceImpl;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SlingServlet(
        paths = {"/bin/bupaforms/generateLetter"}
)
@Properties({@Property(
        name = "service.pid",
        value = {"com.bupa.aemform.aemforms.core.servlets.BupaController"},
        propertyPrivate = false
), @Property(
        name = "service.description",
        value = {"BupaController"},
        propertyPrivate = false
), @Property(
        name = "service.vendor",
        value = {"BUPA"},
        propertyPrivate = false
)})
public class BupaController extends SlingAllMethodsServlet {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    @Reference
    private OutputService outputService;
    Document doc = null;

    protected void doGet(SlingHttpServletRequest req, SlingHttpServletResponse resp)
            throws ServletException, IOException {

        this.logger.info("Inside doGet()");

        String formName = req.getParameter("letterName");
        this.logger.info("FormName received is :" + formName);

        PDFOutputOptions options = new PDFOutputOptions();

        String contentRoot = "C:/ContentRoot";
        String templateStr = "C:/ContentRoot/" + formName + ".xdp";
        String inputFile = "C:/ContentRoot/SampleXML.xml";

        options.setContentRoot(contentRoot);
        options.setAcrobatVersion(AcrobatVersion.Acrobat_11);
        options.setLocale("us");
        options.setLinearizedPDF(true);
        options.setTaggedPDF(true);

        InputStream inputXMLStream = new FileInputStream(inputFile);

        resp.setContentType("application/pdf");
        resp.setHeader("Content-Disposition", "inline; filename=SamplePDF.pdf");

        try {

            Document pdfDoc = this.outputService.generatePDFOutput(templateStr, new Document(inputXMLStream), options);
            if (pdfDoc == null) {
                resp.sendError(500, "PDF generation failed");
                return;
            }

            InputStream docInputStream = pdfDoc.getInputStream();
            ServletOutputStream outputStream = resp.getOutputStream();

            byte[] buffer = new byte[1024];
            int bytesRead;

            while ((bytesRead = docInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            outputStream.flush();
            outputStream.close();
            docInputStream.close();

        } catch (Exception e) {
            e.printStackTrace();
            resp.sendError(500, "PDF generation error");
        }
    }
    protected void doPost(SlingHttpServletRequest req, SlingHttpServletResponse resp) throws ServletException, IOException {
        this.logger.info("*****Inside doPost()");
        req.getResource();
        String formName = req.getParameter("letterName");
        this.logger.info("*****FormName received is :" + formName);
        BufferedReader b = new BufferedReader(req.getReader());
        StringBuffer xmlBuffer = new StringBuffer();
        String xmlString = "";

        while((xmlString = b.readLine()) != null) {
            xmlBuffer.append(xmlString);
        }

        xmlString = xmlBuffer.toString();
        File receivedFile = new File("tempFile");
        FileWriter fr = new FileWriter(receivedFile);
        fr.write(xmlString);
        fr.close();
        this.logger.info("the length of the xml string:" + xmlString.length());
        OutputServiceImpl output = new OutputServiceImpl();

        try {
            this.doc = output.generatedoc(formName, receivedFile, this.outputService);
        } catch (OutputServiceException var15) {
            resp.sendError(500, "Output Service Reported an Error");
            this.logger.info(var15.getMessage());
            var15.printStackTrace();
        }

        ServletOutputStream outputStream = resp.getOutputStream();
        InputStream docInputStream = this.doc.getInputStream();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];

        int bytes;
        while((bytes = docInputStream.read(buffer)) != -1) {
            baos.write(buffer, 0, bytes);
        }

        resp.setContentLength(baos.size());
        resp.setContentType("application/pdf");
        resp.addHeader("Content-Disposition", "inline; filename=SamplePDF.pdf");
        resp.setHeader("Cache-Control", "cache, must-revalidate");
        resp.setHeader("Pragma", "public");
        baos.writeTo(outputStream);
        outputStream.flush();
        outputStream.close();
        if (docInputStream != null) {
            docInputStream.close();
            resp.getWriter().close();
        }

        this.doc.close();
        this.doc.dispose();
    }

    protected void bindOutputService(OutputService var1) {
        this.outputService = var1;
    }

    protected void unbindOutputService(OutputService var1) {
        if (this.outputService == var1) {
            this.outputService = null;
        }

    }
}
